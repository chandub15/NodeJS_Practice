var express = require('express');
var router = express.Router();

var customers = [
{id:"1", 
name:"Vivek", 
email:"vivek@gmail.com",
phone:"87654 67676",
address:"India"
},
{id:"2",name:"Rama",
 email:"rama@gmail.com",
 phone:"89885 67676",
 address:"India"
},
];

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send(customers);
});

module.exports = router;
